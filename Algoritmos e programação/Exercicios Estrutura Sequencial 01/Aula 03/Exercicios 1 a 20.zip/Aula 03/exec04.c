#include <stdio.h>
float main(){
    float salario, novosal;
    printf("Inclua salario atual:\n");
    scanf("%f%*c", &salario );

    novosal = salario + salario * 25/100;

    printf("Salario ajustado = %.2f\n", novosal);
} 