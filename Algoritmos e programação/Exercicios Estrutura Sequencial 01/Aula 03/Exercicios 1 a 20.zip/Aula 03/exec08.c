#include <stdio.h>
float main(){
    float depos, taxa, rendi, totalrend;

    printf("Informe o deposito: \n");
    scanf("%f%*c", &depos);

    printf("Informe taxa de juros: \n");
    scanf("%f%*c", &taxa);

    rendi = depos * taxa/100;
    totalrend = depos + rendi;

    printf("Rendimento real: %.2f \n", rendi);
    printf("Deposito atual: %.2f \n", totalrend);
}