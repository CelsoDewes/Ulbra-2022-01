#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

float main(){

    UINT CPAGE_UTF8 = 65001;
  SetConsoleOutputCP(CPAGE_UTF8);
  
    float altura_degrau, altura_objetivo, quantidade_degraus;

    printf("Informe a altura dos degraus:\n");
    scanf("%f%*c", &altura_degrau);

    printf("Informe a altura que deseja alcançar:\n");
    scanf("%f%*c", &altura_objetivo);

    quantidade_degraus= altura_objetivo/altura_degrau;

    printf("Será necessária a quantidade de %.0f degraus", quantidade_degraus);

}