#include <stdio.h>
float main(){
    float n1, n2, n3, p1, p2, p3, media;
    printf("Inclua nota 01:\n");
    scanf("%f%*c", &n1 );
   
    printf("Inclua peso nota 01:\n");
    scanf("%f%*c", &p1 );
    
    printf("Inclua nota 02:\n");
    scanf("%f%*c", &n2 );
    
    printf("Inclua peso nota 02:\n");
    scanf("%f%*c", &p2 );
    
    printf("Inclua Nota 03:\n");
    scanf("%f%*c", &n3 );

    printf("Inclua peso nota 03:\n");
    scanf("%f%*c", &p3 );

    media= n1 * p1 + n2 * p2 + n3 * p3 / p1 + p2 + p3;

    printf("Media ponderada = %.2f\n", media);
}