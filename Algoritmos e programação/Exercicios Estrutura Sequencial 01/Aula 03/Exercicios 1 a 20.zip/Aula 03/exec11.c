#include <stdio.h>
#include <math.h>
float main(){
    float valor, quadrado, cubo, r2, r3;

    printf("Informe valor positivo e maior que zero:\n");
    scanf("%f%*c", &valor);

    quadrado = valor*valor;
    cubo = valor*valor*valor;
    r2 = sqrt (valor);
    r3= cbrt (valor);

    printf("Valor informado, ao quadrado: %.2f\n", quadrado);
    printf("Valor informado, ao cubo: %.2f\n", cubo);
    printf("Raiz quadrada do valor informado: %.2f\n", r2);
    printf("Raiz ao cubo do valor informado: %.2f\n", r3);
    
}