#include <stdio.h>
float main(){
    float salario, percent, aumento, novosal;
    printf("Inclua salario atual:\n");
    scanf("%f%*c", &salario );

    printf("Inclua percentual de aumento:\n");
    scanf("%f%*c", &percent );

    aumento = salario *percent/100;
    printf("Aumento salarial = %.2f\n", aumento);

    novosal = salario + aumento;
    printf("Novo salario = %.2f\n", novosal);
} 