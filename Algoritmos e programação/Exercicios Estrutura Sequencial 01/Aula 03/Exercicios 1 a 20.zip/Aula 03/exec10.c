#include <stdio.h>
#define pi 3.14
float main(){
    float area, raio;
    printf("Raio do circulo: \n");
    scanf("%f%*c", &raio);

    area= pi * (raio*raio);

    printf("Area do circulo: %.2f \n", area);
}