#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

int main(){

    UINT CPAGE_UTF8 = 65001;
    SetConsoleOutputCP(CPAGE_UTF8);
  
    int peso, gato1, gato2, total;

    printf("Peso do saco de ração\n");
    scanf("%d%*c", &peso);
    
    printf("Quantida de ração do gato 1\n");
    scanf("%d%*c", &gato1);
    
    printf("Quantida de ração do gato 2\n");
    scanf("%d%*c", &gato2);

    gato1= gato1 /1000;
    gato2= gato2 /1000;
    total= peso - 5*(gato1+gato2);

    printf("A quantidade de ração restante é de %d", total);
}