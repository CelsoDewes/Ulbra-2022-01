#include <stdio.h>
int main(){
    int n1, n2, n3, n4, soma;
    printf("Numero 01:\n");
    scanf("%d%*c", &n1 );
   
    printf("Numero 02:\n");
    scanf("%d%*c", &n2 );
    
    printf("Numero 03:\n");
    scanf("%d%*c", &n3 );

    printf("Numero 04:\n");
    scanf("%d%*c", &n4 );
    
    soma = n1 + n2 + n3 + n4;

    printf("soma de n1, n2, n3, n4 = %d\n", soma );
}