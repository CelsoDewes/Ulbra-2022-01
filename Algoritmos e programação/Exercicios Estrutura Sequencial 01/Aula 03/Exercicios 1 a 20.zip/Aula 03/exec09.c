#include <stdio.h>
float main(){
    float base, altura, area;
    
    printf("Base do triangulo: \n");
    scanf("%f%*c", &base);

    printf("Altura do triangulo: \n");
    scanf("%f%*c", &altura);

    area = base * altura /2;
    printf("Area do triangulo: %.2f\n", area);   
}