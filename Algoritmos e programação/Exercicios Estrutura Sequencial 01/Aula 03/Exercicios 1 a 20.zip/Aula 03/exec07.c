#include <stdio.h>
float main(){
    float salario, gratifica, impost, novosal;
    printf("Informe seu salario: \n");
    scanf("%f%*c", &salario);
    
    impost= salario * 10/100;
    gratifica= 50;
    
    novosal= salario + gratifica - impost;
    
    printf("Salario liquido = %.2f\n", novosal);

}