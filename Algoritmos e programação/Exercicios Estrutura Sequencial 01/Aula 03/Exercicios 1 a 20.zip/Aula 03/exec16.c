#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

float main(){

    UINT CPAGE_UTF8 = 65001;
  SetConsoleOutputCP(CPAGE_UTF8);
  
    float horas_trab, salario_min, valor_hora, bruto, liquido, imposto;

    printf("Informe as horas trabalhadas\n");
    scanf("%f%*c", &horas_trab);

    printf("informe o valor do salario minimo\n");
    scanf("%f%*c", &salario_min);

    valor_hora= salario_min/2;
    bruto= valor_hora*horas_trab;
    imposto=bruto*3/100;
    liquido= bruto-imposto;
    printf("O valor das horas trabalhadas da um total de:%.2f\n", liquido);
    return 0;

}