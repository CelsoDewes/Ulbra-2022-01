#include <stdio.h>
#include <math.h>

float main(){
    float valor1, valor2, elevado1, elevado2;

    printf("Informe valor positivo e maior que zero:\n");
    scanf("%f%*c", &valor1);

    printf("Informe novo valor positivo e maior que zero:\n");
    scanf("%f%*c", &valor2);

    elevado1= pow(valor1,valor2);
    elevado2= pow(valor2,valor1);

    printf("Valor 01 elevado ao Valor 02: %.2f\n", elevado1);
    printf("Valor 02 elevado ao Valor 01: %.2f\n", elevado2);
}